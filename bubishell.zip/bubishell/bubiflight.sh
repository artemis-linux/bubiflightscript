cp -rf images ../
cp -rf css ../
cp -rf _locales ../